<form action="sell.php" method="POST">
    <fieldset>
    <h1>Stock Sales</h1>
        <div class="form-group">
            <input autofocus class="form-control" name="symbol" placeholder="Stock symbol" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Sell My Stock</button>
        </div>
    </fieldset>
</form>
    <br>
<div>
    <a href="logout.php">Log Out</a>
</div>

