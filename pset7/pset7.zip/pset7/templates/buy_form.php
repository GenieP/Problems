<form action="buy.php" method="POST">
    <fieldset>
    <h1>Buy Stocks</h1>
        <div class="form-group">
            <input autofocus class="form-control" name="symbol" placeholder="Stock symbol" type="text"/>
        </div>
        <div class="form-group">
            <input autofocus class="form-control" name="shares" placeholder="Number of Shares" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Buy Stocks</button>
        </div>
    </fieldset>
</form>
    <br>
<div>
    <a href="logout.php">Log Out</a>
</div>
