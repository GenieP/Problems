<form action="password.php" method="post">
    <fieldset>
    <h1>Password Change</h1>
        <div>
        <br>
        <br>
        <h3>Your password has been changed successfully!</h3>
        </div>
    </fieldset>
</form>
<br>
<div>
    <a href="logout.php">Log Out</a>
</div>
